/*
 * NRF UriList
 */

package context

type Links struct {
	Item []Item `json:"item" bson:"item"`
}
