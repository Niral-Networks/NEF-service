/*
 * NRF UriList
 */

package context

type Item struct {
	Href string `json:"href" bson:"href"`
}
